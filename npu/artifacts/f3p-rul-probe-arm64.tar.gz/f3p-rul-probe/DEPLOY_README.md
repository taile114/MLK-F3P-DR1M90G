# F3P RUL parser/replay test

This package contains an ARM64 Linux executable compiled with the vendor
Linaro GCC 7.5-2019.12 compiler, matching vendor Arm NN libraries, a verified
FP32 ONNX model, 165 normalized input windows and PyTorch reference outputs.
The executable has not been run on the physical board. The model is not quantized.

On the F3P Linux board, extract into a writable Linux filesystem:

    tar xzf f3p-rul-probe-arm64.tar.gz
    cd f3p-rul-probe
    sha256sum -c deployment.sha256
    sh check_board.sh > board_env.txt 2>&1
    sh run.sh parse

If parsing succeeds, test CpuRef on one window, then all 165 windows:

    sh run.sh cpu 1
    sh run.sh cpu 0

Stop at a failed stage and preserve results/*/probe.log and ldd.txt.
Parser failure precedes backend selection and cannot be fixed by CPU fallback.
Only after driver/PL/CMA readiness is confirmed, test the mixed backend preference:

    sh run.sh mixed 1

Mixed mode requests Alnpu,CpuAcc,CpuRef; requesting Alnpu or obtaining a prediction
does not prove NPU acceleration. The optimized.dot and profile.json outputs are
provided for backend-assignment inspection. Existing FP32/operator limitations remain.

Input: little-endian float32 [1,23,110], 10120 bytes per window.
Output: float32 [1,1], measured in observed aging-test sessions, not hours.
Inputs are already normalized. Labels are only used to report test errors.
The packaged vendor libraries are local to lib/; system libraries are not replaced.

Exit codes: 2 arguments/files; 20 parser; 21 tensor contract; 30 runtime/CMA;
40 optimizer; 50 network load; 60 inference; 70 reference mismatch.
build_info.txt records the actual ELF interpreter and dynamic dependencies.
