F3P parser compatibility controls, version 2.
Requires the original /root/f3p-rul-probe executable and libraries.
Run sha256sum -c checksums.sha256, then sh run_diagnostics.sh on board.
00-03 isolate tensor metadata and negative/positive Unsqueeze axes.
10-20 independently check comparisons, boolean operations, Erf, ReduceL2, Einsum and matrix multiplication.
90-91 are complete model variants; see verification.json for equivalent axis changes.
All 302 original initializers are unchanged. Both complete variants passed all 165 reference windows on PC.
ONNX standard allows negative Unsqueeze axes: https://onnx.ai/onnx/operators/onnx__Unsqueeze.html
No board inference or NPU acceleration has been verified by this package.
