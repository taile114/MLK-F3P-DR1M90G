#!/bin/sh
set -u
ulimit -c 0 2>/dev/null || true
here=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
probe=${1:-/root/f3p-rul-probe}
export LD_LIBRARY_PATH="$probe/lib${LD_LIBRARY_PATH:+:$LD_LIBRARY_PATH}"
if [ ! -x "$probe/bin/rul_probe" ]; then echo "Missing executable: $probe/bin/rul_probe"; exit 2; fi
results="$here/results_$(date +%Y%m%d_%H%M%S)_$$"
mkdir -p "$results" || exit 2
echo "results=$results"
for model in "$here"/models/*.onnx; do
    name=$(basename "$model" .onnx)
    status=0
    "$probe/bin/rul_probe" --model "$model" --parse-only > "$results/$name.log" 2>&1 || status=$?
    printf '%s exit_code=%s\n' "$name" "$status"
    if [ "$status" -ne 0 ]; then tail -n 4 "$results/$name.log"; fi
    printf '%s %s\n' "$name" "$status" >> "$results/summary.txt"
done
echo "--- summary ---"
cat "$results/summary.txt"
echo "results=$results"
