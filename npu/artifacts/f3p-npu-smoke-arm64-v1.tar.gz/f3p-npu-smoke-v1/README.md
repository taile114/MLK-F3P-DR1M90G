# F3P NPU 最小卷积测试

本包独立验证厂商 Arm NN 与 NPU 量化卷积，不使用寿命模型或训练数据，不执行训练。
默认运行库为 SD 系统的 `/opt/armnn_lib/lib`。程序只接受单一 `CpuRef` 或 `Alnpu`，
Alnpu 模式不允许回退 CPU；先执行 CpuRef 对照，失败时不继续执行硬件测试。

原生网络为单个带偏置的 3×3 卷积，NCHW 输入/输出均为 [1,8,8,8]，
stride=1、padding=1、输入与输出 scale=0.25、权重 scale=0.125。
输入和权重为确定的非均匀小整数，偏置为 Signed32。
独立整数卷积公式生成期望值；每种后端运行 3 次，512 个输出均允许最多 1 LSB 量化舍入差。

在 F3P Linux 的新目录解压后执行：

    sha256sum -c checksums.sha256
    sh run.sh inspect
    sh run.sh u8

如 u8 不支持，可继续单独定位不同类型组合：

    sh run.sh u8_s8
    sh run.sh s8

u8 使用 QAsymmU8 激活和权重，零点均为 128；u8_s8 使用 QAsymmU8 激活和
QSymmS8 权重；s8 使用零点为 0 的 QAsymmS8 激活和 QSymmS8 权重。
某一组合不支持不代表其他组合不可用；CPU 对照、硬件优化、加载和数值各自记录。

程序使用厂商 CMA 分配器、导入/导出内存及 cache 同步接口，绕开 ONNX 解析器。
结果目录保存每项退出码、优化图、profile、3 次逐元素 CSV、动态依赖和内核/中断快照。
硬件验证需共同核对 Alnpu 图分配、实际工作负载、数值和中断；设备节点或后端注册本身不足以证明执行。
QEMU 只验证 AArch64 程序及 CPU 数值，不能模拟硬件 NPU。

普通执行超时为 30 秒，存在 timeout 命令时启用；出现超时或驱动错误应保留日志，
停止重复调用并检查板端状态。本包不改写 eMMC、PL、启动文件或系统配置。
SD initramfs 的 /root 不保证掉电保留；可在已确认的 SD 第二分区中新建专用目录保存程序和结果。
