Frozen FKP-DVGT fused CPU / two-branch NPU validation replay

184 validation windows only. No training or held-out test inference.
Provide the exact original weights.bin/weights.tsv, then verify:
sha256sum -c checksums.sha256
sha256sum -c weights.sha256

Paired NPU SD image runtime: /opt/armnn_lib/lib.
Run one group at a time and inspect the saved exit code:
sh run.sh stem
sh run.sh neon 1
sh run.sh neon 0
sh run.sh hybrid 1
sh run.sh hybrid 10
sh run.sh hybrid 0
The wrapper includes a five-window warm-up, persistent buffers, bundled
hardware timeout, IRQ/memory snapshots, and an integer oracle for hybrid.
F3P_VERIFY_INT=0 sh run.sh hybrid 0 disables extra audit IO outside timing.
sh benchmark.sh runs three interleaved rounds of reference/neon/
cpu_quantized/hybrid, all 184 windows, with five warm-ups per process.
It refuses to overwrite an existing benchmark index. Frequencies and
temperature controls were unavailable in the physical benchmark.

CPU kernels keep the original spline grid/order/boundaries, frozen weights,
float32 math, epsilon values and exact GELU. FP32 retains the original
absolute-plus-relative tolerance. Quantized mismatches count deviations
from FP32; they do not imply failed integer kernels or application acceptance.
The global allocation hook counts C++ new/new[] only, not every malloc.
Hybrid uses two isolated aligned UINT8 FCs and imported persistent CMA IO.
CMA cleanup is required after all graph and runtime objects are destroyed.
NPU audit captures actual IO and weights for independent int64 verification.

CXX and ARMNN_ROOT must point at the paired vendor compiler and SDK.
sh build.sh rebuilds both programs. This is a fixed-model prototype;
application integration, long-duration/reload stress and accuracy acceptance
remain separate tasks. Model outputs are aging-test-session counts, not hours.
