# Independent padded native-FC control

The original B=11,I=12,O=21 native FC was accepted by optimization/loading
but physically timed out. Do not rerun that unpadded case on Alnpu.
Recover the hardware by a clean shutdown and full power cycle first.

This package keeps the ORIGINAL B/I/O for synthetic data and the integer
oracle, pads native FC input/output dimensions to multiples of eight, fills
added inputs/weights/biases with real zero, checks padded outputs, and crops
the restored result to the original output count. Zero is byte 128 in U8.
For m06, physical [11,16] x [24,16] weights yields original [11,21] after crop.
This is a hypothesis for a workaround, not an established hardware rule.
No trained weights, calibration data or training are used.

The tested timeout supervisor is INCLUDED in bin/timeout and the runner
prepends that directory to PATH. No separate installer or system changes.
For each shape, CpuRef runs before the single Alnpu backend. No CPU fallback.
The group only invokes fc_pad8, never the known-failing unpadded expression.

On the recovered board, verify checksums.sha256 and run control. Review that
result before first (m06 padded only), then attention (four output-21 shapes),
then matrix (all 24 shapes). Each command is: sh run.sh GROUP.
All unexpected failures stop the group. A driver interrupt timeout or CRASHED
message requires preserving logs and hardware recovery before further calls.

Original program and archive remain unchanged. Three profiled iterations,
no warm-up, diagnostic timings only. CpuRef is not the deployed mixed CPU
performance baseline. CPU/QEMU checks do not establish NPU compatibility.
Keep results on the SD data partition. Use gzip -dc ... | tar -xf -.
