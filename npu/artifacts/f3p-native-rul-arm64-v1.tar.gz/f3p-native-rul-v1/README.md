# F3P native FKP-DVGT deterministic CPU replay

This package uses the trained best.pt checkpoint (epoch 16) without retraining.
Input: normalized Float32 [1,23,110]. Output: Float32 [1,1].
RUL units are observed aging-test sessions, not hours.
Only inputs and checkpoint weights enter the model. Labels and reference predictions are used for verification.

The original 2-block, 3-head KAN/attention model is constructed with vendor Arm NN native layers.
Six CPU network segments surround five host GELU operations using C++ std::erf.
Finite-input float masks avoid the unsupported Boolean-to-Float32 cast.
The executable does not load an ONNX file and requests only CpuRef.

The same ARM64 binary passed all 165 replay windows under QEMU with the vendor runtime.
Maximum reference difference: 7.62939453125e-06.
RMSE against dataset labels: 3.25626653116.
Full-model physical F3P execution is not yet verified. NPU acceleration and quantization are not verified.

Keep the existing /root/f3p-rul-probe/lib directory. This package reuses that vendor library locally.
No board Python, compiler, internet connection or Ubuntu VM is needed for these commands:

    cd /root/f3p-native-rul-v1
    sha256sum -c checksums.sha256
    sh run_native_rul.sh 1
    sh run_native_rul.sh 0

Run all windows only after the first-window command returns exit_code=0.
Each run creates a separate results directory containing probe.log, predictions.csv and loader diagnostics.
Exit 0 means every requested prediction matched its PyTorch reference within atol=rtol=0.0001.
Exit 70 means a numeric mismatch; exit 2 reports a setup, loading or execution failure with a stage name.
The runner prints its log after execution completes. Prediction timing is diagnostic and includes the first forward.

The source is in src/. To rebuild on the development VM:

    export CXX=/home/uisrc/uisrc-lab-anlogic/tools/aarch64-linux/bin/aarch64-linux-gnu-g++
    export ARMNN_ROOT=/home/uisrc/f3p-rul-probe/vendor/armnn
    sh build.sh

build_info.txt records the compiler, ELF machine, loader and dynamic dependencies.
verification.json and emulation_all/ contain the PC-side ARM64 numeric evidence.
contracts/ retains the baseline preprocessing and normalization contract. These replay inputs are already normalized.
