# F3P UINT8 linear-dimension controls

Synthetic controls use the 24 unique FC dimensions of the frozen native RUL
graph. No checkpoint, training dataset, calibration or training is used.

Mappings: fc is native FullyConnected with weights [O,I]. conv expresses the
same matrix as a 1x1 NCHW convolution [1,I,1,B]. conv_pad8 additionally pads
input/output channels to multiples of 8; padding is a hypothesis to test,
not an established hardware requirement. Real zero is encoded as byte 128.
All mappings use QAsymmU8 activations/weights/output, zero-points 128,
input scale .25, weight scale .125, Signed32 zero bias at scale .03125.
The output divisor is 8/16/32/64 for I <=64/256/512/2048 respectively.

Each process changes the input in all three iterations. A separate integer
matrix-product oracle checks all physical outputs, including padded ones,
with tolerance 1 LSB. Test ordering is CpuRef then Alnpu. Exactly one backend
is requested; optimized compute assignments are checked. No CPU fallback is
permitted for Alnpu. Graphs, profiles, element CSV, final physical output bytes,
dequantized original output, memory snapshots and IRQ snapshots are saved.

On F3P, from this extracted directory, use the paired SD runtime:

    sha256sum -c checksums.sha256
    sh run.sh control

After reviewing that result, continue with sh run.sh smoke (6 representative
model shapes), then sh run.sh matrix (all 24 shapes). Control uses an 8x8x8
matrix and tests native FC and 1x1 convolution. The matrix group contains
72 mapping cases; smoke is a subset of it.

Each case has a 30-second timeout. Only Alnpu optimize rejection (40) is
recorded as a capability restriction and allowed to continue. CPU failure,
load failure, numerical mismatch, crash or timeout stops the survey.
The final survey-completed message does not mean every mapping is supported.

Enqueue time and quantize/pack/enqueue/sync/restore time are reported separately.
The latter includes layout conversion and output dequantization, excluding
synthetic input generation, reference computation and file output. All three
iterations are profiled, with no warm-up: these are diagnostic times, not
steady-state latency or a full-RUL speedup measurement.

Use gzip -dc PACKAGE.tar.gz | tar -xf - on the paired BusyBox image.
Keep results on the SD second partition, not the small boot partition or
initramfs /root. Do not extract over existing results. Board execution is
separate from QEMU CPU prechecks; QEMU cannot validate physical NPU support.
