# F3P CPU acceleration diagnostic package

This new package supports CpuRef, CpuAcc, and CpuAcc,CpuRef preference order.
The root wrappers default to CpuAcc,CpuRef; the nested runner defaults to CpuRef.
It preserves the verified checkpoint weights and all 165 normalized replay windows.
Only CPU backends are requested. NPU acceleration and quantization are not tested.

Requires the existing /root/f3p-rul-probe/lib vendor runtime.
Run on the F3P Linux shell:

    sha256sum -c checksums.sha256
    sh check_npu.sh
    sh run_layers.sh
    F3P_PROFILE=1 sh run_rul.sh 1
    sh run_rul.sh 0
    sh run_rul.sh 0 CpuRef

check_npu.sh is read-only; it does not load modules, modify FPGA state or flash files.
The layer suite has 14 positive controls and one unsupported Boolean Cast control.
The expected Cast exit is 50 for the mixed preference, and 40 for CpuRef-only.
Boolean outputs are compared as truth values while raw codes are logged.
CpuAcc-only rejects the Ceil-based masks. Mixed execution keeps Ceil on CpuRef.

QEMU passed all positive layer controls with fallback and all 165 full-model windows.
Full-model maximum reference error is approximately 8.58e-06, with no mismatches.
This is not yet a physical F3P test of the mixed backend. Emulator times are not board performance.
The QEMU graph assigns 1724 compute nodes to CpuAcc and 60 Ceil nodes to CpuRef.
Node counts do not measure FLOP proportions or performance speedup.

Each full-model run writes graphs, optimizer messages, probe.log and predictions.csv
to native-rul/results_<backend>_<timestamp>_<pid>/.
F3P_PROFILE=1 enables first-window profiling and writes segment_*_profile.json.
Profiling is disabled for later windows; use default profiling-off runs for timing comparisons.
Old /root/f3p-native-rul-v1 and its files are unchanged.
