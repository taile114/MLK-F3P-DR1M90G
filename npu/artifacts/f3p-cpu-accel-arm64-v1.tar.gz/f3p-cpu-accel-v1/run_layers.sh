#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec sh "$root/native-layers/run_native_layers.sh" "${1:-CpuAcc,CpuRef}"
