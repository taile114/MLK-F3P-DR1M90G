#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
exec sh "$root/native-rul/run_native_rul.sh" "${1:-1}" "${2:-CpuAcc,CpuRef}"
