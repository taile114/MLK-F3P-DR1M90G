Parser-only diagnostic controls. Requires the existing /root/f3p-rul-probe binary and libraries.
Extract this archive on the board Linux filesystem. Run: sh run_diagnostics.sh
00: one Relu; 01-04: original model prefixes through Transpose, Reshape, Unsqueeze and Less.
Raw/typed pairs differ only in INT64 initializer encoding, retaining identical integer values.
10: full original model with inferred tensor metadata.
11: full model with inferred metadata and typed INT64 initializers.
No quantization, retraining, NPU inference or system-library replacement is performed.
Full variants passed all 165 PyTorch reference windows on PC ONNX Runtime.
Results from the vendor parser on F3P are not yet available.
