#!/bin/sh
set -eu
root=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
: "${CXX:?Set paired compiler}"
: "${ARMNN_ROOT:?Set paired runtime}"
for target in native_rul_offload npu_op_support; do
out=rul_offload
if [ "$target" = npu_op_support ]; then out=npu_op_support; fi
"$CXX" -std=c++17 -O3 -ffp-contract=off -Wall -Wextra -Wpedantic \
 -I"$ARMNN_ROOT/include" -I"$root/src" "$root/src/$target.cpp" \
 -L"$ARMNN_ROOT/lib" -Wl,-rpath-link,"$ARMNN_ROOT/lib" -larmnn -pthread -ldl -o "$root/bin/$out"
done
