Frozen FKP-DVGT additional-offload experiment.
Paired validation: 184 windows, five warm-ups, three rounds of five modes.
Supported full-replay plans: head2, ff4, ff6, input_ff5 (input uses 1x1 Conv).
input_ff7 and all-124 plans are exploration inputs, not full-replay validated configurations.
Float32 baseline remains within its original tolerance. Quantized models are not FP32-equivalent.
Application accuracy thresholds and independent held-out testing remain pending.

Provide byte-identical weights.bin/weights.tsv from f3p-native-rul-arm64-v1.tar.gz.
Run sha256sum -c checksums.sha256 and sha256sum -c weights.sha256 before use.
Use a new Linux directory. The vendor BusyBox tar lacks -z: gzip -dc PACKAGE | tar -xf -.
Start with sh run.sh profile 1; then profile 0.
For NPU, run hybrid 1 PLAN, hybrid 10 PLAN, only then the full benchmark.
input_ff5 uses: sh run.sh hybrid 1 qparams_input_ff5.tsv conv_input.txt.
Integer audit is enabled by default for individual runs; benchmark_offload.sh disables it.
Full timings include conversion, packing and synchronization, exclude initialization and raw audit IO.
sh support.sh optimizes ten Float32 graphs without loading/enqueuing hardware.
The probe remains a separate experiment and does not choose an application default.
