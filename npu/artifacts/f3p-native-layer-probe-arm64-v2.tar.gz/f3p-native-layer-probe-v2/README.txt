F3P native Arm NN CPU capability probe, version 2.
Uses the existing /root/f3p-rul-probe/lib vendor runtime.
Run: sha256sum -c checksums.sha256
Then: sh run_native_layers.sh

CPU buffers use MemorySource::Undefined with import/export disabled.
This matches the normal copy-based CPU workload path.

Fourteen controls were executed under QEMU AArch64 with the same vendor library.
Thirteen controls passed numeric checks with zero observed error.
The direct cast_bool_float control remains unsupported (exit 40), as expected.
The float comparison masks and spline interval gate avoid that Boolean cast.
Included boundary cases cover equal endpoints and adjacent float/subnormal values.
See emulation_results/ for the complete emulator-side outputs.

Physical F3P execution of this version is not yet verified.
This is a small-layer capability test, not the full RUL model.
No NPU backend is requested and no system library is replaced.
Erf/full-model assembly, quantization and NPU driver/backend readiness remain unverified.

QEMU tool: Ubuntu official archive qemu-user-static 6.2+dfsg-2ubuntu6.32 amd64.
https://archive.ubuntu.com/ubuntu/pool/universe/q/qemu/
