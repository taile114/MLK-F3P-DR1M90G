Frozen-weight FKP-DVGT CPU/NPU validation replay

This package contains the 184-window validation set; no held-out test data.
Copy the byte-identical weights.bin and weights.tsv from the verified CPU
bundle into this directory, or create symlinks to those exact files.
sha256sum -c checksums.sha256
sha256sum -c weights.sha256

On the paired vendor NPU SD image:
sh run.sh hybrid 1
sh run.sh hybrid 10
sh run.sh hybrid 0
sh run.sh baseline 0
sh run.sh cpu_quantized 0
Count 0 means all 184 validation windows. Review each run before continuing.
The script uses the bundled timeout, stores graphs/profiles/CSV/IRQ/memory,
and releases the serial port through the separate Windows serial tool.
The board script itself does not operate a serial port.

Runtime: /opt/armnn_lib/lib, ArmNN 32.1 vendor build with Alnpu.
Six persistent runtimes avoid switching loaded networks on each Enqueue.
Only the last two segments use the registered vendor CMA allocator.
CMA session cleanup remains required after network/runtime destruction.
Original FP32 tolerance counters are retained in quantized output; they are
not an integer-kernel error counter or an application acceptance threshold.
CPU/NPU mixed validation passed for two head spline branches, not all layers.
Diagnostic profiling and memory tracing are enabled; timings are not a
formal warmed performance benchmark. Production accuracy threshold is TBD.

Rebuild with the paired CXX and ARMNN_ROOT variables, then sh build.sh.
