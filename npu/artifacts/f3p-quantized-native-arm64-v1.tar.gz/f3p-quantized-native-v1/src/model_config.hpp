#pragma once
namespace native_config {
constexpr unsigned kHeads = 3;
constexpr unsigned kTemporalDim = 21;
constexpr unsigned kSpatialDim = 21;
constexpr unsigned kTemporalFF = 140;
constexpr unsigned kSpatialFF = 140;
constexpr float kLambda = 5.000000000e-01f;
constexpr float kOneMinusLambda = 5.000000000e-01f;
}
